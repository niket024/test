public interface G
{
	public static final int I = 90; // Constants
	int j = 90;
}
