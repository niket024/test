
public class FourWheeler implements Vehicle
{
	@Override
	public void cost()
	{
		System.out.println("four wheeler cost:"+500000);
		
	}

	@Override
	public void speed()
	{
		System.out.println("four wheeker spped:"+300 +" kmph");
		
	}
	
}
