package example.vehicle;

public interface Vehicle
{
	int getSpeed();

	int getCost();
}
