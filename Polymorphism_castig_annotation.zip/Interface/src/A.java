public interface A
{
	public abstract void test();


}
