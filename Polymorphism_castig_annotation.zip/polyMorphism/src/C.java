public class C extends B
{
	int i =30;
	void test()
	{
		System.out.println("test-C");
	}
}
