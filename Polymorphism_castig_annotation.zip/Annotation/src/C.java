
public class C
{
	@Deprecated
   void test()
   {
	   System.out.println("test");
   }
}
