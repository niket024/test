public class B extends A
{
	@Override
	void test()
	{
		System.out.println("test");
	}

	void test1()
	{
		System.out.println("test1");
	}
	@Override
	public String toString()
	{
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}
