public class A extends Object
{
	void test()
	{
		System.out.println("test");
	}
}
