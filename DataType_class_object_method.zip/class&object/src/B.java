public class B
{
	static int i = 10;

	public static void main(String[] args)
	{
		int i = 20;
		System.out.println(i);
	}
}
