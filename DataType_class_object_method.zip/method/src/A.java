public class A
{
	void test1()
	{
		System.out.println("Without arg and without return type");
	}

	void test2(int i, int j)
	{
		System.out.println("With arg and without return type");
	}

	int test3()
	{
		System.out.println("Without arg and with return type");
		return 8;
	}

	int test4(int i)
	{
		System.out.println("With arg and with return type");
		return i;
	}

	public static void main(String[] args)
	{

		A a1 = new A();
		a1.test1();
		a1.test2(2, 6);
		int k = a1.test3();
		a1.test3();
		int l = a1.test4(23);
		System.out.println(k);
		System.out.println(l);
		System.out.println("main");
	}
}
