public class C
{
	void test() throws InterruptedException
	{
		Thread.sleep(10000);
	}
}
