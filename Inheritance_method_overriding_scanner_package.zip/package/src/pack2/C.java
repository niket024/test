package pack2;

import pack1.*;

public class C
{
	public static void main(String[] args)
	{
		A a1 = new A();
		System.out.println(a1.i);
		B b1 = new B();
	}
}
