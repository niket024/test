import java.util.Date;

public class B
{
	public static void main(String[] args)
	{
		Date d1 = new Date(0);
		System.out.println(d1);
	}
}
  