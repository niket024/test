import java.util.Date;

public class E
{
	public static void main(String[] args)
	{
		Date d1 = new Date();
		long l = d1.getTime();
		System.out.println(d1);
		System.out.println(l);
	}
}
