import java.util.Calendar;
import java.util.Date;

public class G
{
	public static void main(String[] args)
	{
		Calendar cal = Calendar.getInstance();

		Date d1 = cal.getTime();
		
		System.out.println(d1);
	}
}
