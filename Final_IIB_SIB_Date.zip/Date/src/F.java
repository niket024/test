import java.util.Calendar;

public class F
{
	public static void main(String[] args)
	{
		Calendar cal = Calendar.getInstance();
		System.out.println(cal);
	}
}
