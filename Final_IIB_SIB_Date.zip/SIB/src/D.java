public class D
{
	 int i = test();

	 int test()
	{
		System.out.println(i);
		return 9;
	}
	public static void main(String[] args)
	{
//		System.out.println(i);
//		test();
	}
}
