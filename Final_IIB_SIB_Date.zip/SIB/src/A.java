public class A
{
	
	static
	{
		System.out.println("SIB");
	}
	
	static void test()
	{
		System.out.println("test");
	}
	public static void main(String[] args)
	{
		A.test();
	}
}
