public class C extends B
{

	@Override
	void test()
	{
		// TODO Auto-generated method stub
		super.test();
	}
}
