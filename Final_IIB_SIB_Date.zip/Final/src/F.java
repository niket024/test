public interface F
{
	public static final int i=90;
	int j;
}
