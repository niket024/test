 class B
{
	B()
	{
		// TODO Auto-generated constructor stub
	}

	B(int i)
	{
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)
	{
		B b2 = new B();
		B b1 = new B(12);
		System.out.println("main");
	}

}
