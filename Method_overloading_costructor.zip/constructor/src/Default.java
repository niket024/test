public class Default
{
	public Default()
	{
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)
	{
		Default d1 = new Default();

		System.out.println("main");
	}
}
