public class A1
{

	int i;

	A1(int i)
	{
		this.i = i;
	}

	public static void main(String[] args)
	{
		A1 a1 = new A1(10);
		System.out.println(a1.i);
	}
}
