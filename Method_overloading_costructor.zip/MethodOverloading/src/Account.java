public class Account
{
	public void register(String name, int age)
	{
		System.out.println("You are rigistered!!");
	}

	public void register(String name, int age, int mobNo)
	{
		System.out.println("You are rigistered!!");
	}
}
