function validateForm() 
{
	var f1 = document.forms[0];
	var em = f1.email;
	if (em.value.length == 0) {
		alert("This field should  must be filled out");
        return false;
    }    
    var atpos = em.value.indexOf("@");
    var dotpos = em.value.lastIndexOf(".");
    if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= em.value.length) {
        alert("Not a valid e-mail address");
        return false;
    }
	return true;
}