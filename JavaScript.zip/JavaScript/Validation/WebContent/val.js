function validateForm()
{
	var f1=document.forms[0];
	var fn=f1.fname;
if (fn.value.length==0)
  {
  alert("First name must be filled out");
  return false;
  }
  return true;
}