package example;

public class Manager
{
	static void callMethod(RBI r1)//null
	{
		System.out.println(r1.getROI());;
	}
	static public  void main(String args...)
	{
		SBI s1=new SBI();
		callMethod(s1);
		//System.out.println(s1.getROI());
		System.out.println("-----------------");
		HDFC h1=new HDFC();
		callMethod(h1);
		//System.out.println(h1.getROI());
	}
}
