package example.vehicle;

import java.util.Scanner;

public class Manager
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("*********Vehicle details******");
		System.out.println("1.Two wheeler");
		System.out.println("2.Four wheeler");
		System.out.println("Enter your choice(1-2)");
		int ch = sc.nextInt();
		System.out.println("Here is the details:");
		System.out.println("----------------------");
		if (ch == 1)
		{
			TwoWheeler twoWheeler = new TwoWheeler();
			System.out.println("Two wheeler cost = " + twoWheeler.getCost());
			System.out.println("Two wheeler speed = " + twoWheeler.getSpeed() + " kmph");
		}
		else if (ch == 2)
		{
			FourWheeler fourWheeler = new FourWheeler();
			System.out.println("Four wheeler cost = " + fourWheeler.getCost());
			System.out.println("four wheeler speed = " + fourWheeler.getSpeed()+ " kmph");
		}
		else{
			System.out.println("Wrong choice");
		}
	}
}
