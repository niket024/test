public class B implements C
{

	@Override
	public void test()
	{
		// TODO Auto-generated method stub
		
	}
	public void test3()
	{
		
	}
	
}