
public class F implements C
{

	@Override
	public void test()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test1()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test3()
	{
		// TODO Auto-generated method stub
		
	}

}
