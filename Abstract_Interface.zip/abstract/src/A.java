abstract class A
{
	abstract public void test();
	abstract public void test1();
	void test2()
	{
		
	}

}