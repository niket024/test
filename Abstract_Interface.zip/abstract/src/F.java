abstract public class F
{
	F()
	{
		System.out.println("f-cons");
	}
	
}
