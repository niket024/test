
public  class D extends C
{

	@Override
	void test4()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test1()
	{
		// TODO Auto-generated method stub
		
	}

	
	
}
