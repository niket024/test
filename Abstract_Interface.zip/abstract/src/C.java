abstract class C extends A
{
	abstract void test4();
}
