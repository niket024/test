public abstract class A1
{
	abstract public void test();
	void test2()
	{
		
	}
}
