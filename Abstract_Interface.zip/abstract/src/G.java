public class G extends F
{
	G()
	{
		System.out.println("g-cons");
	}

	public static void main(String[] args)
	{
		G g1 = new G();

	}
}
