package com.nik;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class DBUtil {

	public static int register(String fname, String lname, String uname,
			String pwd) {
		int status = 0;
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		try {
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test",
					"sa", "");
			stmt = con.createStatement();
			String sql = "insert into registration values(" + getRegId() + ",'"
					+ fname + "','" + lname + "','" + uname + "','" + pwd
					+ "')";
			status = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			stmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	private static int getRegId() {
		Random rand = new Random();
		int n = rand.nextInt(50);
		return n;
	}

}
